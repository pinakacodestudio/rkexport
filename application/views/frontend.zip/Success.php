<div class="notfound">
    <div class="container">
        <div class="row">
            <div class="content text-center">
                <div class="col-md-12 successfull_img">
                <img src="<?=FRONT_URL?>assets/images/successfull_img.gif" class="img-responsive">
                </div>
                <div class="col-md-12">
                <h4>Your Payment is Successfull!</h4>
                <div class="lines">
                    <div class="line1"></div>
                    <div class="line2"></div>
                </div>
                <p>Thank you for your payment. An automated payment receipt will be send to your registered email.</p>
                <div class="btn btn-home" onclick="location.href='<?=FRONT_URL?>products'">
                    <a href="<?=FRONT_URL?>products">Continue Shopping</a>
                </div>
            
            </div>
                
            </div>
        </div>
    </div>
</div>
