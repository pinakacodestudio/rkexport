<div class="notfound">
    <div class="container">
        <div class="row">
            <div class="contents text-center">
                <h1>404</h1>
                <h4>Nothing was found</h4>
                <div class="soon">oops</div>
                <div class="lines">
                    <div class="line1"></div>
                    <div class="line2"></div>
                </div>
                <p>The page requested couldn't be found. This could be a spelling error in the<br>URL or a removed page.</p>
                <div class="btn btn-home" onclick="location.href='<?=FRONT_URL?>'">
                    <a href="<?=FRONT_URL?>">Back to home</a>
                </div>
            </div>
        </div>
    </div>
</div>