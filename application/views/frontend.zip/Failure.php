<div class="notfound">
    <div class="container">
        <div class="row">
            <div class="content text-center">
                <div class="col-md-12 failed_img">
                <img src="<?=FRONT_URL?>assets/images/Error.gif" class="img-responsive">
                </div>
                <div class="col-md-12">
                <h4>Transaction failed</h4>
                <div class="lines">
                    <div class="line1"></div>
                    <div class="line2"></div>
                </div>
                <p>your transaction failed to be written to the blockchain. <br />This is usually because of network congestion. Please try again.</p>
                <div class="btn btn-home" onclick="location.href='<?=FRONT_URL?>products'">
                    <a href="<?=FRONT_URL?>products">Try again</a>
                </div>
            
            </div>
                
            </div>
        </div>
    </div>
    </div>
