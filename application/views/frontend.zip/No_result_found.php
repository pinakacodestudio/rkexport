<div class="maintain-page">
    <div class="contents text-center notfound">
        <div class="error_img">
            <img src="<?=FRONT_URL?>assets/images/searchresultnotfound.jpg" class="img-responsive">
        </div>
        
        <h4>Sorry, no results found!</h4>
        <div class="soon">oops</div>
        <div class="lines">
            <div class="line1"></div>
            <div class="line2"></div>
        </div>
        <p>Please check the spelling or try searching for something else</p>
        <div class="btn btn-home" onclick="location.href='<?=FRONT_URL?>'">
            <a href="<?=FRONT_URL?>">Back to Home</a>
        </div>
    </div>
</div>